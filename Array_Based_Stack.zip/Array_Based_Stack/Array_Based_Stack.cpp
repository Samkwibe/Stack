/*
Samuel KWibe
 ID # 2278332
 Email: Samuel.kwibe@snhu.edu
 class :217
In - Class Assignment # 4
Array - Based Stack

In this assignment, I'm going to build a program that's like a stack for keeping track of student records. 
Each record in this stack will include details like the student's name, ID, phone number,
and home address. My task is to enable adding new records on top of the stack, which
is known as "pushing," and also removing the most recent record, referred to as "popping."
Besides these, I'll also make functions to check how many records are currently in the stack,
see if the stack is empty, and find out who the most recent student added is.
*/ 





#include "ArrayBasedStack.h"
#include <iostream>
using namespace std;

void displayMenu();
void performPush(ArrayBasedStack& stack);
void performPop(ArrayBasedStack& stack);
void displayTop(const ArrayBasedStack& stack);

int main()
{
    ArrayBasedStack stack;
    char choice;

    do
    { // this do while lop will keep on checking and reaping until when the used select the exit
        displayMenu();
        cin >> choice;

        switch (choice)
        {
        case '1':
            performPush(stack);
            break;
        case '2':
            performPop(stack);
            break;
        case '3':
            cout << "Size of stack: " << stack.size() << endl;
            break;
        case '4':
            cout << (stack.empty() ? "Stack is empty" : "Stack is not empty") << endl;
            break;
        case '5':
            cout << (stack.full() ? "Stack is full" : "Stack is not full") << endl;
            break;
        case '6':
            displayTop(stack);
            break;
        case '7':
            cout << "Exiting program." << endl;
            break;
        default:
            cout << "Invalid choice. Please try again." << endl;
        }
    } while (choice != '7');

    return 0;
}
// this is the menu for the studntdent infomation that will be display on the screen for the usr
void displayMenu()
{
    cout << "+==========================================+" <<endl;
    cout << "1. Push (Add a student)\n";
    cout << "2. Pop (Remove the most recent student)\n";
    cout << "3. Size (Get the number of students in the stack)\n";
    cout << "4. Empty (Check if the stack is empty)\n";
    cout << "5. Full (Check if the stack is full)\n";
    cout << "6. Top (View the most recent student)\n";
    cout << "7. Exit\n";
    cout << "Enter your choice: ";
    cout << "+==========================================+" << endl;

    cout <<" " << endl;
}

void performPush(ArrayBasedStack& stack)
{
    if (stack.full())
    {
        cout << "Stack is full. Cannot add more students." << endl;
        return;
    }

    Info newItem;
    cout << "Enter student's name: ";
    cin.ignore(); // this will clear newline character from the stream
    getline(cin, newItem.name);
    cout << "Enter student's ID: ";
    getline(cin, newItem.id);
    cout << "Enter student's phone number: ";
    getline(cin, newItem.phone);
    cout << "Enter student's address: ";
    getline(cin, newItem.address);
    stack.push(newItem);
    cout << "Student added to stack." << endl;
}

void performPop(ArrayBasedStack& stack)
{
    if (stack.empty())
    {
        cout << "Stack is empty. No students to remove." << endl;
    }
    else
    {
        Info removedItem = stack.pop();
        cout << "Student " << removedItem.name << " removed from stack." << endl;
    }
}

void displayTop(const ArrayBasedStack& stack)
{
    if (stack.empty())
    {
        cout << "Stack is empty. No student to display." << endl;
    }
    else
    {
        Info topItem = stack.topItem();
        cout << "Most recent student details:" << endl;
        cout << "Name: " << topItem.name << endl;
        cout << "ID: " << topItem.id << endl;
        cout << "Phone: " << topItem.phone << endl;
        cout << "Address: " << topItem.address << endl;
    }
}
