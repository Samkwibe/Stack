#include "ArrayBasedStack.h"
#include <string>


ArrayBasedStack::ArrayBasedStack() : top(-1) {}

void ArrayBasedStack::push(const Info& info) {
    if (!full()) {
        StudentInfo[++top] = info;
    }
}

Info ArrayBasedStack::pop() {
    if (!empty()) {
        return StudentInfo[top--];
    }
    return Info{}; // This return an empty student information if the stack is empty
}

int ArrayBasedStack::size() const {
    return top + 1;
}

bool ArrayBasedStack::empty() const {
    return top == -1;
}

bool ArrayBasedStack::full() const {
    return top == MAX_STUDENTINFO - 1;
}

Info ArrayBasedStack::topItem() const {
    if (!empty()) {
        return StudentInfo[top];
    }
    return Info{}; // This one will return an empty infomation if the stack is empty
}

