#ifndef ARRAYBASEDSTACK_H
#define ARRAYBASEDSTACK_H

#include <string>

const int MAX_STUDENTINFO = 100; // Maximum number of items in the stack

struct Info {
    std::string name;
    std::string id;
    std::string phone;
    std::string address;
};

class ArrayBasedStack {
private:
    Info StudentInfo[MAX_STUDENTINFO];
    int top;

public:
    ArrayBasedStack();
    void push(const Info& info);
    Info pop();
    int size() const;
    bool empty() const;
    bool full() const;
    Info topItem() const;
};

#endif // ARRAYBASEDSTACK_H
